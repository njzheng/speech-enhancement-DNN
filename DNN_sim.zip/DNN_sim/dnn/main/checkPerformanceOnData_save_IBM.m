function [perf,perf_str,estoi_perf] = checkPerformanceOnData_save_IBM(net,data,label,opts,write_wav,...
                                                                                                        mvn_handle,noise, feat)
% this function is to test the traing net with test data and labels

% load the handle to get the 
DFI = mvn_handle.DFI; % double start and end indeces
mix_cell = mvn_handle.mix_cell;
speech_cell = mvn_handle.speech_cell;

disp('save_IBM_func');
num_test_sents = size(DFI,1);

if nargin < 6
    num_split = 1;
end

num_samples = size(data,1);

if ~opts.eval_on_gpu
    for i = 1:length(net)
        net(i).W = gather(net(i).W);
        net(i).b = gather(net(i).b);
    end
    data = gather(data);
end

output = getOutputFromNetSplit(net,data,5,opts);


%% resynthesis with feat_para
global feat_para;
fs=feat_para.fs;
feat_paras=feat_para; % avoid in the parfor

est_r = cell(num_test_sents);
ideal_r = cell(num_test_sents);
clean_s = cell(num_test_sents);
mix_s = cell(num_test_sents);
EST_MASK = cell(num_test_sents);
IDEAL_MASK = cell(num_test_sents);

noise_feat = sprintf('%-15s', [noise ' ' feat]);

% the stoi scores
est_stoi = zeros(num_test_sents,1);
ideal_stoi = zeros(num_test_sents,1);
unproc_stoi = zeros(num_test_sents,1);
parfor i=1:num_test_sents
    EST_MASK{i} = transpose(output(DFI(i,1):DFI(i,2),:));
    IDEAL_MASK{i} = transpose(label(DFI(i,1):DFI(i,2),:));

    mix = double(mix_cell{i});
    mix_s{i} = mix;
    est_r{i} = synthesis(mix, double(EST_MASK{i}),feat_paras);
    ideal_r{i} = synthesis(mix, double(IDEAL_MASK{i}),feat_paras);

    clean_s{i} = double(speech_cell{i});
    est_stoi(i) = estoi(clean_s{i}, est_r{i}, fs);
    ideal_stoi(i) = estoi(clean_s{i}, ideal_r{i}, fs);
    unprocessed_stoi(i) = estoi(clean_s{i}, mix, fs);
    fprintf(1,['#ESTOI_single# ' noise_feat ' index=%d unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'], i, unprocessed_stoi(i), ideal_stoi(i), est_stoi(i));

    %compute pitch contours
%     clean_sig = floor(2^15*clean_s{i}/(max(abs(clean_s{i})))); % normalize
end

% sum the stoi all
stoi_est_sum = sum(est_stoi);
stoi_ideal_sum = sum(ideal_stoi);
stoi_unproc_sum = sum(unprocessed_stoi);   
estoi_perf.est_stoi=est_stoi;
estoi_perf.ideal_stoi=ideal_stoi;
estoi_perf.unproc_stoi=unproc_stoi;

fprintf(1,['\n#STOI_average# ' noise_feat ' unprocessed_stoi=%0.4f ideal_stoi=%0.4f est_stoi=%0.4f \n'], stoi_unproc_sum/num_test_sents, stoi_ideal_sum/num_test_sents, stoi_est_sum/num_test_sents);

global mainpath;
issave =0;
if(issave ==1)
    currentpath = [mainpath,filesep,'DATA',filesep,noise,filesep,'dnn'];
    save_prefix_path = [currentpath,filesep,'STORE' filesep 'db' num2str(opts.db) filesep];
    if ~exist(save_prefix_path,'dir'); mkdir(save_prefix_path); end;
    if ~exist([save_prefix_path 'EST_MASK'],'dir'); mkdir([save_prefix_path 'EST_MASK' ]); end;
    if ~exist([save_prefix_path 'sound'],'dir'); mkdir([save_prefix_path 'sound']); end;
    save([save_prefix_path 'EST_MASK' filesep 'binary_MASK_' noise '_' feat '.mat' ],'EST_MASK','IDEAL_MASK','DFI');
    save([save_prefix_path 'sound' filesep 'binary_' noise '_' feat '.mat'],'est_r','ideal_r', 'clean_s', 'mix_s');

    [current_acc,hit,fa] = getHITFA(label(:),prediction(:));
    perf = hit - fa; perf_str = 'HIT-FA';
    format_print([current_acc, hit, fa, hit-fa],noise, feat);

    pause(5);
    save_wav_path = ['WAVE' filesep];
    if ~exist(save_wav_path,'dir'); mkdir(save_wav_path); end;

    save_wav_path = [save_wav_path 'db' num2str(opts.db) filesep];
    if ~exist(save_wav_path,'dir'); mkdir(save_wav_path); end;

    save_wav_path = [save_wav_path 'binary_'];

    if write_wav == 1
        %write to wav files
        disp('writing waves ......');
        warning('off','all');
        for i=1:num_test_sents
           sig = mix_s{i};
           sig = sig/max(abs(sig))*0.9999;
           audiowrite([save_wav_path num2str(i) '_mixture.wav'], sig,fs);

           sig = clean_s{i};
           sig = sig/max(abs(sig))*0.9999;
           audiowrite([save_wav_path num2str(i) '_clean.wav'], sig,fs);

           sig = ideal_r{i};
           sig = sig/max(abs(sig))*0.9999;
           audiowrite([save_wav_path num2str(i) '_ideal.wav'], sig,fs);

           sig = est_r{i};
           sig = sig/max(abs(sig))*0.9999;
           audiowrite([save_wav_path num2str(i) '_estimated.wav'], sig,fs);
        end
        warning('on','all');
        disp('finish waves');
    end
end
