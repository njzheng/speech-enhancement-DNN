function [model, netgrad] = funcDeepNetTrain3(mvn_handle,opts,MASK_index,model)
% this function is for training dnn from trainning data and labels
% the structure is in opts
% using the multi-frame targets for output

%% network initialization
if (nargin== 4)
    isfunetuning =1;
else
    isfunetuning =0;
end

%% --data intialization--
% only load cv data and labels for its small size
cv_data = mvn_handle.cv_data;
cv_label = mvn_handle.cv_label;
% set the input data for dnn
cv_data = make_window_buffer(cv_data, opts.train_neighbour);
cv_label = make_window_buffer(cv_label, opts.label_neighbour);

% when load train data and labels, remind the memory
train_data_org = mvn_handle.train_data.';
train_label_org = mvn_handle.train_label.';

%%
isGPU = opts.isGPU;
fprintf(1,'1 MASK_index=%d\n',MASK_index);
net_struct = opts.net_struct;
if (isfunetuning ==0)
    if opts.isPretrain
        disp('start RBM pretraining... waste of memory!')
        t_data = make_window_buffer(train_data_org.',opts.train_neighbour);
        pre_net = pretrainRBMStack(t_data,opts);
        disp('RBM pretraining done.')
    else
        disp('use random weight initialization.')
        isSparse = 0; isNorm = 1;
        pre_net = randInitNet(net_struct,isSparse,isNorm,isGPU); % a structure contian gpuArray objects   
    end 
   
    % the variable of the change: increasing, gradiant, ada
    net_weights_inc = zeroInitNet(net_struct, opts.isGPU);
    net_grad_ssqr = zeroInitNet(net_struct, opts.isGPU, eps);
    net_ada_eta = zeroInitNet(net_struct, opts.isGPU);
else
    disp('use the existing model and netgrads.')
    pre_net = model; % a structure contian gpuArray objects 
    
    % the variable of the change: increasing, gradiant, ada
    netgrad = model.netg;
    net_weights_inc=netgrad.net_weights_inc;
    net_grad_ssqr = netgrad.net_grad_ssqr;
    net_ada_eta = netgrad.net_ada_eta;
end

net_iterative = pre_net;
num_net_layer = length(net_iterative);
[~,num_samples] = size(train_data_org);

%% divide the space of the train_data (not the real data) into several batches spaces (blocks)
% to fit the small GPU memory size machines
btime=8; % if your GPU memory size is large, you can increase btime for faster computation
sgd_block_size = opts.sgd_batch_size*btime; % a block contains several batch
block_id = genBatchID(num_samples, sgd_block_size); 
num_block= size(block_id,2); % for each trainning data
fprintf('\nNum of Training Samples:%d with blocks: %d and batches: %d \n',num_samples,num_block,num_block*btime);

sgd_batch_size = opts.sgd_batch_size;
% batch_id = genBatchID(num_samples,opts.sgd_batch_size);
% num_batch = size(batch_id,2); % for each trainning data
fprintf('\n batch size is : %d \n',sgd_batch_size);

disp('net_strunct:');disp(net_struct);
disp('train_data:');disp(size(mvn_handle,'train_data'));

% recording each epoch s data at gpu for final selection.
rec_epoch_num = min(opts.sgd_max_epoch,5); % the last 5 iterative models are used for selection
cv_rec = repmat(struct,rec_epoch_num,1);

% train_data = make_window_buffer(train_data_org,opts.train_neighbour);

%% traing epoches times
% for each epoch, it should test all the batches and all the train data
for epoch = 1:opts.sgd_max_epoch
    tic;
    seq = randperm(num_samples); % randperm dataset every epoch
    cost_sum = 0; % cost for each epoch
      
    for bid = 1:num_block-1 % avoid being out of range
        perm_block_idx = seq(block_id(1,bid):block_id(2,bid));
        
        % for each batch, there is an associated row
        perm_idx = sort(reshape(perm_block_idx(:),[],btime).',2);     
        % it contains several bathes in one block
        perm_idx_sort = reshape(perm_idx.',1,[]);
        
        % using multi-frame style for data and targets
        train_data_block = make_window_buffer3(train_data_org,perm_idx_sort,opts.train_neighbour,btime);
        train_label_block = make_window_buffer3(train_label_org,perm_idx_sort,opts.label_neighbour,btime);

        if isGPU
            gpu_train_data_block = gpuArray(train_data_block);
            gpu_train_label_block = gpuArray(train_label_block);
        end
        
        for bbid = 1:btime
            % using part of the data to use neighbor
            % load into GPU      
            if isGPU
                % divided the block into several batches
                batch_data = gpu_train_data_block(:,:,bbid);
                batch_label = gpu_train_label_block(:,:,bbid);
            else            
                batch_data = train_data_block(:,:,bbid);
                batch_label = train_label_block(:,:,bbid);
            end

            if epoch>opts.change_momentum_point
                momentum=opts.final_momentum;
            else
                momentum=opts.initial_momentum;
            end

            %backprop: #core code#:  compute the Net Gradient and Cost
            [cost,net_grad] = computeNetGradientNoRolling(net_iterative, batch_data, batch_label, opts);
            cost_sum = cost_sum + cost;

            %supports only sgd
            for ll = 1:num_net_layer
                switch opts.learner
                    case 'sgd'
                        net_weights_inc(ll).W = momentum*net_weights_inc(ll).W + opts.sgd_learn_rate(epoch)*net_grad(ll).W;
                        net_weights_inc(ll).b = momentum*net_weights_inc(ll).b + opts.sgd_learn_rate(epoch)*net_grad(ll).b;
                    case 'ada_sgd' % not consider sgd_learn_rate
                        net_grad_ssqr(ll).W = net_grad_ssqr(ll).W + (net_grad(ll).W).^2;
                        net_grad_ssqr(ll).b = net_grad_ssqr(ll).b + (net_grad(ll).b).^2;

                        net_ada_eta(ll).W = opts.ada_sgd_scale./sqrt(net_grad_ssqr(ll).W);                    
                        net_ada_eta(ll).b = opts.ada_sgd_scale./sqrt(net_grad_ssqr(ll).b);

                        net_weights_inc(ll).W = momentum*net_weights_inc(ll).W + net_ada_eta(ll).W.*net_grad(ll).W;
                        net_weights_inc(ll).b = momentum*net_weights_inc(ll).b + net_ada_eta(ll).b.*net_grad(ll).b;
                end

                net_iterative(ll).W = net_iterative(ll).W - net_weights_inc(ll).W;
                net_iterative(ll).b = net_iterative(ll).b - net_weights_inc(ll).b;
            end    
        end
%     disp(['bid: ',num2str(bid)]);
    end
    fprintf('Objective cost at epoch %d: %2.2f \n', epoch, cost_sum);

    % check perf. on cv data,
    % if target is different, the following is different

    if ~mod(epoch,opts.cv_interval)
        if MASK_index == 0
            disp('binary mask');
            [perf, perf_str] = checkPerformance_iterative_IBM(net_iterative,cv_data,cv_label,opts);
        else
            disp('ratio mask');
            [perf, perf_str] = checkPerformance_iterative_IRM(net_iterative,cv_data,cv_label,opts);
        end
        % save the last number of the net
        if(epoch>opts.sgd_max_epoch-rec_epoch_num)
            mepoch = epoch-(opts.sgd_max_epoch-rec_epoch_num); % later the beginning
            cv_rec(mepoch*opts.cv_interval).perf = perf;
            cv_rec(mepoch*opts.cv_interval).model = net_iterative;
        end
        toc;
    end
 end


%% use the best model on dev_set
if MASK_index == 0 
    % maximize HIT-FA tp get best model for estimated binary mask
    [m_v,m_i] = max([cv_rec.perf]);
else
    % minimize MSE to get best model for estimated wiener mask 
    [m_v,m_i] = min([cv_rec.perf]);
end
model = cv_rec(m_i*opts.cv_interval).model;

% net parameters of grads
netgrad.net_weights_inc=net_weights_inc;
netgrad.net_grad_ssqr = net_grad_ssqr;
netgrad.net_ada_eta = net_ada_eta;
% model.netgrad=netg;

fprintf('\ntest_set: Best model (selected by validation set) at epoch %d\n',opts.sgd_max_epoch-rec_epoch_num+m_i);
