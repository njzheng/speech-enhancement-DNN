function [perf,perf_str,estoi_perf] = checkPerformanceOnData_save_wiener(net,data,label,opts,write_wav,...
                                                                                                   mvn_handle,noise, feat)
% this function is to test the traing net with test data and labels
% data and label is testing data
call_pesq=0;
% load the handle to get the 
DFI = mvn_handle.DFI; % double start and end indeces
mix_cell = mvn_handle.mix_cell;
speech_cell = mvn_handle.speech_cell;


disp('save_wiener_func'); 
% number of the test sentences
num_test_sents = size(DFI,1);

num_samples = size(data,1);

% net is storen in GPU
if ~opts.eval_on_gpu
    for i = 1:length(net)
        net(i).W = gather(net(i).W);
        net(i).b = gather(net(i).b);
    end
    data = gather(data);% 3227 x 64 (freq)
end


% num_split = 1;???? why is 5 ?
% data: 3227 x 1230 (freq)
% output: 3227 x 64 (gt_freq)
output = getOutputFromNetSplit(net,data,5,opts);

%% resynthesis with feat_para
global feat_para;
fs=feat_para.fs;
feat_paras=feat_para; % avoid in the parfor

% the estimated (processed) ouput from mix
est_r = cell(num_test_sents);
ideal_r = cell(num_test_sents);
clean_s = cell(num_test_sents);
mix_s = cell(num_test_sents);
EST_MASK = cell(num_test_sents);
IDEAL_MASK = cell(num_test_sents);
noise_feat = sprintf('%-15s', [noise ' ' feat]);
% the stoi scores
est_stoi = zeros(num_test_sents,1);
ideal_stoi = zeros(num_test_sents,1);
unproc_stoi = zeros(num_test_sents,1);

for i=1:num_test_sents
    % the frame duration is DFI(i,1)~DFI(i,2)
    EST_MASK{i} = transpose(output(DFI(i,1):DFI(i,2),:));
    IDEAL_MASK{i} = transpose(label(DFI(i,1):DFI(i,2),:));

    mix = double(mix_cell{i});
    % even for ideal_r, when change feat_para the stoi may change
    est_r{i} = synthesis(mix, double(EST_MASK{i}), feat_paras); 
    ideal_r{i} = synthesis(mix, double(IDEAL_MASK{i}), feat_paras);
    clean_s{i} = double(speech_cell{i});
    mix_s{i} = mix;
    
    %1. get the stoi scores, related with the clean speech
    est_stoi(i) = estoi(clean_s{i}, est_r{i}, fs);
    ideal_stoi(i) = estoi(clean_s{i}, ideal_r{i}, fs); 
    unproc_stoi(i) = estoi(clean_s{i}, mix, fs);
    fprintf(1,['#ESTOI_single# ' noise_feat ' index=%d unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'],...
        i, unproc_stoi(i), ideal_stoi(i), est_stoi(i));

end

% the total mse
mse = getMSE(output, label);
% sum the stoi all
stoi_est_sum = sum(est_stoi);
stoi_ideal_sum = sum(ideal_stoi);
stoi_unproc_sum = sum(unprocessed_stoi);   
estoi_perf.est_stoi=est_stoi;
estoi_perf.ideal_stoi=ideal_stoi;
estoi_perf.unproc_stoi=unproc_stoi;
% print the average stoi score
fprintf(1,['\n#STOI_average# ' noise_feat ' unprocessed_stoi=%0.4f ideal_stoi=%0.4f est_stoi=%0.4f \n'],...
    stoi_unproc_sum/num_test_sents, stoi_ideal_sum/num_test_sents, stoi_est_sum/num_test_sents);

%% save the data and wav, and use exe to get pesq
global mainpath;
dnn_path=[mainpath,filesep,'DATA',filesep,noise,filesep,'dnn'];

STORE_path = [dnn_path,filesep,'STORE' filesep 'db' num2str(opts.db) filesep];
if ~exist(STORE_path,'dir'); mkdir(STORE_path); end;
if ~exist([STORE_path 'EST_MASK'],'dir'); mkdir([STORE_path 'EST_MASK' ]); end;
if ~exist([STORE_path 'sound'],'dir'); mkdir([STORE_path 'sound']); end;
save([STORE_path 'EST_MASK' filesep 'ratio_MASK_' noise '_' feat '.mat' ],'EST_MASK','IDEAL_MASK','DFI');
save([STORE_path 'sound' filesep 'ratio_' noise '_' feat '.mat'],'est_r','ideal_r', 'clean_s', 'mix_s');

% return criteria
% performance and its type
perf = mse; perf_str = 'MSE';
fprintf(1, 'noise_feat: %s ;  %s : %0.4f \n' ,noise_feat,perf_str,perf);


issave =0;
if(issave ==1)
    % WAV_path = [dnn_path,filesep,'WAVE' filesep];
    % if ~exist(WAV_path,'dir'); mkdir(WAV_path); end;

    WAV_path = [dnn_path,filesep,'WAVE' filesep 'db' num2str(opts.db) filesep];
    if ~exist(WAV_path,'dir'); mkdir(WAV_path); end;

    WAV_path = [WAV_path 'ratio_'];

    %   SCORES is a two element array: [ PESQ_MOS, MOS_LQO (ignore) ] 
    %   for narrowband mode, or a scalar for the wideband mode: MOS_LQO
    mode = 'nb';%  'nb' or wideband: 'wb'
    binary = [mainpath,filesep,'dnn',filesep,'main',filesep,'pesq.exe'];
    pesq_est_sum =0;
    pesq_ideal_sum = 0;
    pesq_unproc_sum = 0;

    if write_wav == 1
        %write to wav files
        disp('writing waves ......');
        warning('off','all');
        for i=1:num_test_sents
           sig = mix_s{i};
           sig = sig/max(abs(sig))*0.9999;
           mixture_path=[WAV_path num2str(i) '_mixture.wav'];
           audiowrite(mixture_path, sig,fs);

           sig = clean_s{i};
           sig = sig/max(abs(sig))*0.9999;
           clean_path=[WAV_path num2str(i) '_clean.wav'];
           audiowrite(clean_path, sig,fs);

           sig = ideal_r{i};
           sig = sig/max(abs(sig))*0.9999;
           idea_path=[WAV_path num2str(i) '_ideal.wav'];
           audiowrite(idea_path,sig,fs);

           sig = est_r{i};
           sig = sig/max(abs(sig))*0.9999;
           estimate_path=[WAV_path num2str(i) '_estimated.wav'];
           audiowrite(estimate_path,sig,fs);

           if call_pesq==1
            %2. get the pesq scores, related with the clean speech
    %         pesq2_mtlb( reference, degraded, fs, mode, binary)
            est_pesq = pesq2_mtlb(clean_path, estimate_path, fs,mode, binary);
            ideal_pesq = pesq2_mtlb(clean_path, idea_path, fs,mode, binary); 
            unproc_pesq = pesq2_mtlb(clean_path, mixture_path, fs,mode, binary);
            fprintf(1,['#PESQ_single# ' noise_feat ' index=%d unprocessed_pesq=%0.4f ideal_pesq=%0.4f est_pesq=%0.4f \n'],...
            i, unproc_pesq, ideal_pesq, est_pesq);

            % sum the pesq all        
            pesq_est_sum = pesq_est_sum + est_pesq;
            pesq_ideal_sum = pesq_ideal_sum + ideal_pesq;
            pesq_unproc_sum = pesq_unproc_sum + unproc_pesq;      
           end
        end   
        fprintf(1,['\n#PESQ_average# ' noise_feat ' unprocessed_pesq=%0.4f ideal_pesq=%0.4f est_pesq=%0.4f \n'],...
        pesq_unproc_sum/num_test_sents, pesq_ideal_sum/num_test_sents, pesq_est_sum/num_test_sents);

        warning('on','all');
        disp('finish waves');
    end
end