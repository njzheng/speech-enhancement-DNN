function [cost, net_gradients] = computeNetGradientNoRolling(net, data, label, opts)
% data and lable is gpuarray object

num_net_layer = length(net);
unit_type_output = opts.unit_type_output;
unit_type_hidden = opts.unit_type_hidden;

[forward_path, drop_mask] = forwardPass(net, data, opts);
[num_sample, num_feat] = size(data);
output = forward_path{num_net_layer+1}.';
%% cost function: mse, xentropy, softmax_xentropy
switch opts.cost_function
    case 'mse'
        error = label-output;
        cost = (1/2)*sum(sum(error.^2))/num_sample;
        output_delta = -error.*compute_unit_gradient(output,unit_type_output);
        
    case 'xentropy'
        cost = -mean(label.*log(output) + (1-label).*log(1-output));
        if strcmp(unit_type_output,'sigm')
            output_delta = -(label-output);
        else
            output_delta = -(label-output)./(output.*(1-output)).*compute_unit_gradient(output,unit_type_output);
        end
    case 'softmax_xentropy'
        cost = -sum(sum(label.*log(output)))/num_sample;
        assert(strcmp(unit_type_output,'softmax'));
        output_delta = -(label-output);
end
%% backprop
layer_grad = cell(num_net_layer,1);
for ll = 1:num_net_layer
    layer_grad{ll} = compute_unit_gradient(forward_path{ll},unit_type_hidden);
end

net_gradients = zeroInitNet(opts.net_struct,opts.isGPU);

upper_layer_delta = output_delta;
for ll = num_net_layer: -1: 1
    net_gradients(ll).W = (mtimes(forward_path{ll},upper_layer_delta))'*(1/num_sample);
    net_gradients(ll).b = mean(upper_layer_delta)';
    
    if opts.isDropout==1
        upper_layer_delta = (mtimes(upper_layer_delta,net(ll).W)'.*drop_mask{ll}.*layer_grad{ll})';
    else
        upper_layer_delta = (mtimes(upper_layer_delta,net(ll).W)'.*layer_grad{ll})';
    end
    
end
