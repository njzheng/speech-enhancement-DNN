function output = getOutputFromNetSplit(net,data,num_split,opts,isoncpu)
% (net,data,5,opts,1);

if nargin <5
    isoncpu = 0;
end

num_samples = size(data,1);
dim_output = opts.net_struct(end);
chunck_size = ceil(num_samples/num_split);


if opts.eval_on_gpu&&~isoncpu
    output = gpuArray.zeros(num_samples,dim_output,'single');
else
    output = zeros(num_samples,dim_output,'single');
end

for i = 1:num_split
    idx_start = (i-1)*chunck_size+1;
    idx_end = i*chunck_size;
    if idx_end>num_samples; idx_end = num_samples; end
    if isoncpu==0
        data_truncate = gpuArray(data(idx_start:idx_end,:));
    else
        data_truncate = data(idx_start:idx_end,:);
    end
    output_chunck = getOutputFromNet(net,data_truncate,opts);
    output(idx_start:idx_end,:) = output_chunck;
end

% for multi-frame output average, no use here 
ln = opts.label_neighbour;
% only for check at last on cpu not for gpu
if ln>0&&(isoncpu)
    single_dim = dim_output/(2*ln+1);
    output2 = output.'; % transpose it for reshape
    
    output3 = zeros(single_dim,num_samples);
    output2 = reshape(output2,single_dim,[]);
    num_block = size(output2,2);
    space = 2*ln+1; % the number of a row
    for k =1:num_samples
        end_c = space*k+1;
        start_c = end_c-(space+1);
        mid_c = (end_c+start_c)/2;
        if(start_c<1)
            start_c = (start_c+end_c)/2;
            assert(start_c>0);
        elseif(end_c>num_block)
            end_c = (start_c+end_c)/2;
            assert(end_c<=num_block);
        end   
%         temp_block = output2(:,start_c:(ln+1):end_c); 
        output3(:,k) = output2(:,mid_c);
%         output3(:,k) = mean(output2(:,start_c:(ln+1):end_c),2);
    end
    
    output = output3.';
end

end