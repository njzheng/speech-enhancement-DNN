function se_align = spalign(clean,noisy,Lw,overlap)
% using signalaligns to get the alignment of the speech 
% using OLA to sythesis a new one
% inputs are column vectors

len = length(clean);
% win = hanning(Lw);
win = ones(Lw,1); % rectangle window
noverlap = fix(Lw*overlap);
nshift = Lw - noverlap;
%% segment

assert(length(clean)==length(noisy));


%overlaps or underlaps successive frames in the output matrix by p samples:
cframe = buffer(clean,Lw,noverlap,'nodelay') ;
nframe = buffer(noisy,Lw,noverlap,'nodelay') ;

% assert(size(cframe,2)==nseg);% nseg = floor(len/nshift);
nseg = size(cframe,2);
cwin = cframe.*win;
nwin = nframe.*win;

%% segalign
anwin = nwin;% initialize
maxlag = 8;
theta = 4e-4;
for i=1:nseg
    if( sum(cwin(:,i).^2)/Lw>theta)
        [a,b,d] = alignsignals(cwin(:,i),nwin(:,i),maxlag);
        if(d>=0)
            % If Y is delayed with respect to X, then D is positive and X is delayed by D samples.
            anwin(:,i) = [nwin(d+1:end,i);zeros(d,1)];
        else
            d = abs(d);
            anwin(:,i) = [zeros(d,1);nwin(1:end-d,i)];
        end
    end
end

%% synthesis
win2 = hamming(Lw);

cwin2 = cwin.*win2;
nwin2 = nwin.*win2;
anwin2 = anwin.*win2;

clean2 = zeros(len+Lw,1);
noisy2 = zeros(len+Lw,1);
se_align = zeros(len+Lw,1);
win_resy = zeros(len+Lw,1);

for i=1:nseg
    ss = (i-1)*nshift+1;
    se = ss+Lw-1;
    clean2(ss:se) = clean2(ss:se)+cwin2(:,i);
    noisy2(ss:se) = noisy2(ss:se)+nwin2(:,i);
    se_align(ss:se) = se_align(ss:se)+anwin2(:,i);    
    win_resy(ss:se) = win_resy(ss:se)+win2;
end
clean2 = clean2(1:len)./win_resy(1:len);
noisy2 = noisy2(1:len)./win_resy(1:len);
se_align = se_align(1:len)./win_resy(1:len);

%  plot(clean./clean2);
% plot(se_align,'DisplayName','se_align');
% 
% hold on;
% plot(noisy,'DisplayName','noisy');
% plot(clean2,'DisplayName','clean2');
% plot(noisy2,'DisplayName','noisy2');
% plot(clean,'DisplayName','clean');
% hold off;

end
