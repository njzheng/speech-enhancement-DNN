function [perf,perf_str,estoi_perf] = checkPerformance_stft(net,data,label,opts,write_wav,...
                                                                                                   mvn_handle,noise, feat)
%CHECKPERFORMANCE_STFT Summary of this function goes here
%   Detailed explanation goes here
% this function is to test the traing net with test data and labels
% the data has already be buffered
% the lables are [IRM, IF]
%------------------------------------------2017/4/17-----------------------------

call_pesq=0;
% load the handle to get the 
DFI = mvn_handle.DFI; % double start and end indeces
mix_cell = mvn_handle.mix_cell;
speech_cell = mvn_handle.speech_cell;

disp('save_stft_func'); 
% number of the test sentences
num_test_sents = size(DFI,1);
num_samples = size(data,1);

% net is storen in GPU
if ~opts.eval_on_gpu
    for i = 1:length(net)
        net(i).W = gather(net(i).W);
        net(i).b = gather(net(i).b);
    end
    data = gather(data);% 3227 x 5*(514 or 513) (freq)
end


% input data is a matrix : 3227 x 5*(514 or 513)(freq)
% output: 3227 x 513 (gt_freq) [IRM, IF]
output = getOutputFromNetSplit(net,data,5,opts);

%% resynthesis with feat_para
global feat_para;
fs=feat_para.fs;
feat_paras=feat_para; % avoid in the parfor

% the estimated (processed) ouput from mix
est_r = cell(1,num_test_sents);
ideal_r = cell(1,num_test_sents);
clean_s = cell(1,num_test_sents);
EST_MASK = cell(1,num_test_sents);
IDEAL_MASK = cell(1,num_test_sents);

noise_feat = sprintf('%-10s', [noise ' ' feat]);
% the stoi scores
est_stoi = zeros(num_test_sents,1);
ideal_stoi = zeros(num_test_sents,1);
unproc_stoi = zeros(num_test_sents,1);
parfor i=1:num_test_sents
    % the frame duration is DFI(i,1)~DFI(i,2)
    EST_MASK{i} = transpose(output(DFI(i,1):DFI(i,2),:)); % covert to freq x time
    IDEAL_MASK{i} = transpose(label(DFI(i,1):DFI(i,2),:));

    mix = double(mix_cell{i});
    % even for ideal_r, when change feat_para the stoi may change
    est_speech = synthesis_with_phase(mix, double(EST_MASK{i}), feat_paras); 
    ideal_speech = synthesis_with_phase(mix, double(IDEAL_MASK{i}), feat_paras);
    est_r{i} = est_speech(feat_paras.Lw*feat_paras.overlap+1:end);% truncate the beginning
    ideal_r{i}= ideal_speech(feat_paras.Lw*feat_paras.overlap+1:end);% truncate the beginning
    len = length(est_r{i});
    clean_s{i} = double(speech_cell{i}(1:len));
    mix = mix(1:len);
    
    %1. get the stoi scores, related with the clean speech
    if(opts.isestoi ==1)
        est_stoi(i) = estoi(clean_s{i}, est_r{i}, fs);
        ideal_stoi(i) = estoi(clean_s{i}, ideal_r{i}, fs); 
        unproc_stoi(i) = estoi(clean_s{i}, mix, fs);
        fprintf(1,['#ESTOI_single# ' noise_feat ' index=%d unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'],...
            i, unproc_stoi(i), ideal_stoi(i), est_stoi(i));
    else
        est_stoi(i) = stoi(clean_s{i}, est_r{i}, fs);
        ideal_stoi(i) = stoi(clean_s{i}, ideal_r{i}, fs); 
        unproc_stoi(i) = stoi(clean_s{i}, mix, fs);
        fprintf(1,['#STOI_single# ' noise_feat ' index=%d unprocessed_stoi=%0.4f ideal_stoi=%0.4f st_estoi=%0.4f \n'],...
            i, unproc_stoi(i), ideal_stoi(i), est_stoi(i));
    end

end

% the total mse
mse = getMSE(output, label);

% sum the stoi all
stoi_est_sum = sum(est_stoi);
stoi_ideal_sum = sum(ideal_stoi);
stoi_unproc_sum = sum(unproc_stoi);   
% print the average stoi score
if(opts.isestoi ==1)
    fprintf(1,['\n#ESTOI_average# ' noise_feat ' unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'],...
        stoi_unproc_sum/num_test_sents, stoi_ideal_sum/num_test_sents, stoi_est_sum/num_test_sents);
else
    fprintf(1,['\n#STOI_average# ' noise_feat ' unprocessed_stoi=%0.4f ideal_stoi=%0.4f est_stoi=%0.4f \n'],...
        stoi_unproc_sum/num_test_sents, stoi_ideal_sum/num_test_sents, stoi_est_sum/num_test_sents);
end
%% save the data and wav, and use exe to get pesq
isdraw = 1;
if(isdraw==1)
    plot(est_stoi);hold on;
    plot(ideal_stoi);
    plot(unproc_stoi);
end
estoi_perf.est_stoi=est_stoi;
estoi_perf.ideal_stoi=ideal_stoi;
estoi_perf.unproc_stoi=unproc_stoi;
perf = mse; perf_str = 'MSE';
end

