function [perf,perf_str] = checkPerformance_iterative_IRM(net,data,label,opts)

if ~opts.eval_on_gpu
    for i = 1:length(net)
        net(i).W = gather(net(i).W);
        net(i).b = gather(net(i).b);       
    end
    data = gather(data);
end

% split the cv data for 5 parts to check, save memory
output = getOutputFromNetSplit(net,data,5,opts);

% mse = getMSE(output, label);
mse = mean2((output-label).^2); % average mean of the matrix
if opts.eval_on_gpu
    mse =gather(mse);
end

perf = mse; perf_str = 'MSE';
fprintf(1,[ '#MSE#  MSE: ' num2str(mse,'%0.4f')  '\n']);
