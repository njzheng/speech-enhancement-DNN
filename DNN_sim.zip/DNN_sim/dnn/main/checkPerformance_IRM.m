function [perf,stoi_perf,estoi_perf,pesq_perf,SDR_perf] = checkPerformance_IRM(net,data,label,opts,write_wav,...
                                                                                                   mvn_handle,noise, feat)
%CHECKPERFORMANCE_STFT Summary of this function goes here
%   Detailed explanation goes here
% this function is to test the traing net with test data and labels
% the data has already be buffered
% the lables are [IRM, IF]
%------------------------------------------2017/4/17-----------------------------

% load the handle to get the 
DFI = mvn_handle.DFI; % double start and end indeces
mix_cell = mvn_handle.mix_cell;
c_mat = mvn_handle.c_mat;
speech_cell = mvn_handle.speech_cell;

disp('save_stft_func'); 
% number of the test sentences
num_test_sents = size(DFI,1);
num_samples = size(data,1);

% net is storen in GPU
for i = 1:length(net)
    net(i).W = gather(net(i).W);
    net(i).b = gather(net(i).b);
end
data = gather(data);% 3227 x 5*(514 or 513) (freq)

% input data is a matrix : 3227 x 5*(514 or 513)(freq)
% output: 3227 x 513 (gt_freq) [IRM, IF]
fprintf('get output from net');
disp(datetime('now'));
output = getOutputFromNetSplit(net,data,5,opts,1); % isoncpu=1
disp(datetime('now'));

%% resynthesis with feat_para
global feat_para;
fs=feat_para.fs;
feat_paras=feat_para; % avoid in the parfor

% the estimated (processed) ouput from mix
est_r = cell(1,num_test_sents);
ideal_r = cell(1,num_test_sents);
clean_s = cell(1,num_test_sents);
mix_s = cell(1,num_test_sents);
EST_MASK = cell(1,num_test_sents);
IDEAL_MASK = cell(1,num_test_sents);

noise_feat = sprintf('%-10s', [noise ' ' feat]);
% the stoi scores
est_stoi = zeros(num_test_sents,1);
ideal_stoi = zeros(num_test_sents,1);
unproc_stoi = zeros(num_test_sents,1);

est_estoi = zeros(num_test_sents,1);
ideal_estoi = zeros(num_test_sents,1);
unproc_estoi = zeros(num_test_sents,1);

est_SDR = zeros(num_test_sents,1);
ideal_SDR = zeros(num_test_sents,1);
unproc_SDR = zeros(num_test_sents,1);

parfor i=1:num_test_sents
    % the frame duration is DFI(i,1)~DFI(i,2)
    EST_MASK{i} = transpose(output(DFI(i,1):DFI(i,2),:)); % covert to freq x time
    IDEAL_MASK{i} = transpose(label(DFI(i,1):DFI(i,2),:));

    mix = double(mix_cell{i})./c_mat(i);
    % even for ideal_r, when change feat_para the stoi may change
    est_r{i} = synthesis_with_IRM(mix, double(EST_MASK{i}), feat_paras); 
    ideal_r{i} = synthesis_with_IRM(mix, double(IDEAL_MASK{i}), feat_paras);

	% using estimated RM + ideal phase 
% 	ideal_r{i} = synthesis_with_IRM_p(mix, double(EST_MASK{i}),speech_cell{i}, feat_paras);

	
    len = length(est_r{i});
    clean_s{i} = double(speech_cell{i}(1:len));
    mix = mix(1:len);
    mix_s{i} = mix;
    
    %1. get the stoi scores, related with the clean speech
%     if(opts.isestoi ==1)
        est_estoi(i) = estoi(clean_s{i}, est_r{i}, fs);
        ideal_estoi(i) = estoi(clean_s{i}, ideal_r{i}, fs); 
        unproc_estoi(i) = estoi(clean_s{i}, mix, fs);
        fprintf(1,['#ESTOI_single# ' noise_feat ' index=%d unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'],...
            i, unproc_estoi(i), ideal_estoi(i), est_estoi(i));
%     else
        est_stoi(i) = stoi(clean_s{i}, est_r{i}, fs);
        ideal_stoi(i) = stoi(clean_s{i}, ideal_r{i}, fs); 
        unproc_stoi(i) = stoi(clean_s{i}, mix, fs);
        fprintf(1,['#STOI_single# ' noise_feat ' index=%d unprocessed_stoi=%0.4f ideal_stoi=%0.4f est_stoi=%0.4f \n'],...
            i, unproc_stoi(i), ideal_stoi(i), est_stoi(i));
%     end

	%2. get the SDR, related with the clean speech
	[est_SDR(i),~,~,~]=bss_eval_sources( est_r{i}',clean_s{i}');
	[ideal_SDR(i),~,~,~]=bss_eval_sources( ideal_r{i}',clean_s{i}');
	[unproc_SDR(i),~,~,~]=bss_eval_sources( mix',clean_s{i}');
	
	fprintf(1,['#SDR_single# ' noise_feat ' index=%d unprocessed_sdr=%0.4f ideal_sdr=%0.4f est_sdr=%0.4f \n'],...
            i, unproc_SDR(i), ideal_SDR(i), est_SDR(i));

end

% the total mse
mse = getMSE(output, label);

% sum the stoi all
estoi_est_sum = sum(est_estoi);
estoi_ideal_sum = sum(ideal_estoi);
estoi_unproc_sum = sum(unproc_estoi);   

stoi_est_sum = sum(est_stoi);
stoi_ideal_sum = sum(ideal_stoi);
stoi_unproc_sum = sum(unproc_stoi); 

SDR_est_sum = sum(est_SDR);
SDR_ideal_sum = sum(ideal_SDR);
SDR_unproc_sum = sum(unproc_SDR); 
  
% print the average stoi score
% if(opts.isestoi ==1)
    fprintf(1,['\n#ESTOI_average# ' noise_feat ' unprocessed_estoi=%0.4f ideal_estoi=%0.4f est_estoi=%0.4f \n'],...
        estoi_unproc_sum/num_test_sents, estoi_ideal_sum/num_test_sents, estoi_est_sum/num_test_sents);
% else
    fprintf(1,['\n#STOI_average# ' noise_feat ' unprocessed_stoi=%0.4f ideal_stoi=%0.4f est_stoi=%0.4f \n'],...
        stoi_unproc_sum/num_test_sents, stoi_ideal_sum/num_test_sents, stoi_est_sum/num_test_sents);
% end
    fprintf(1,['\n#SDR_average# ' noise_feat ' unprocessed_SDR=%0.4f ideal_SDR=%0.4f est_SDR=%0.4f \n'],...
        SDR_unproc_sum/num_test_sents, SDR_ideal_sum/num_test_sents, SDR_est_sum/num_test_sents);

%% save the data and wav, and use exe to get pesq
global mainpath;
dnn_path=[mainpath,filesep,'DATA',filesep,noise,filesep,'dnn'];
WAV_path = [dnn_path,filesep,'WAVE' filesep 'db' num2str(opts.db) filesep];
if ~exist(WAV_path,'dir'); mkdir(WAV_path); end;
MASK_index = feat_paras.MASK_index;
WAV_path = [WAV_path 'ratio' num2str(MASK_index) '_'];

[pesq_perf]=pesq_fun(mix_s,clean_s,ideal_r,est_r, fs,WAV_path);


%%
isdraw = 0;
if(isdraw==1)
    plot(est_estoi);hold on;
    plot(ideal_estoi);
    plot(unproc_estoi);
end
estoi_perf.est_estoi=est_estoi;
estoi_perf.ideal_estoi=ideal_estoi;
estoi_perf.unproc_estoi=unproc_estoi;

stoi_perf.est_stoi=est_stoi;
stoi_perf.ideal_stoi=ideal_stoi;
stoi_perf.unproc_stoi=unproc_stoi;

SDR_perf.est_SDR=est_SDR;
SDR_perf.ideal_SDR=ideal_SDR;
SDR_perf.unproc_SDR=unproc_SDR;

perf = mse;
% perf_str = 'MSE';
end

