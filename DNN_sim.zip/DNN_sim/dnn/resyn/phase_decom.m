function [ s_phase ] = phase_decom( sc_phase,hop)
%PHASE_DECOM Summary of this function goes here
%   Detailed explanation goes here


[nf,nt]=size(sc_phase);

% compensate the phase based on its corresponding frequency
% construct the compensate phase matrix
com_phase=wrapToPi(pi*((1:nf)-1).'/(nf-1)*hop*(1:nt));

s_phase=(sc_phase+com_phase);

end

