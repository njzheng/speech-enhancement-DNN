function [ny_resy ] = synthesis_with_phase(noisy, mask, feat_para) 
%SYNTHESIS_WITH_PHASE Summary of this function goes here
%   Detailed explanation goes here
% this funciton is for synthesis with phase information
% the noisy the time axis vector
% the first half of the mask is the magnitude mask, e.g., IRM, IAM, PSM
%-------------------2017/4/17------------------------------------

% use_phase = 0;

Fs = feat_para.fs;
Lw = feat_para.Lw;
nfft = 2^nextpow2(Lw);
overlap = feat_para.overlap;
SNR = feat_para.snr_set;

noverlap  = round(Lw*overlap); % number of overlap
hop=Lw-noverlap; % time shift
win = hamming(Lw);
MASK_index = feat_para.MASK_index;

% get the spectrogram of noisy speech
% noisy = [zeros(Lw*overlap,1);noisy];
nysp = spectrogram(noisy,win,noverlap,nfft,Fs);
nysp_mag=abs(nysp);
nysp_phase=angle(nysp);% angle with lie between ����.

%% make use of the IRM mask
IRM_len = round(nfft/2)+1;
% dived the mask into magnitude and phase
IRM = mask(1:IRM_len,:);


% only use IRM
% nysp_process_irm = nysp_mag.*sqrt(IRM.^(1/beta)).*exp(1j*nysp_phase);% 
% ny_resy_irm = stft_resynthesis(nysp_process_irm,win,noverlap,nfft );

%% make use of the IRM mask and IF mask
alpha = 0; % only when IRM> alpha, record the intial phase
nysp_phase_com=phase_com(nysp_phase,hop);
en_phase_com = initial_phase(IRM,nysp_phase_com, alpha);

% get the IF:  MIF = MIF./(2*pi)+0.5; 
MIF = mask(IRM_len+1:end,:);
IF = (MIF-0.5)*2*pi;

% com_phase_freq=pi/(nf-1)*hop; % the compensate phase across freqency
sp_mag = nysp_mag.*IRM;
num_neighbor = 1;

%--------- method
en_phase_com = addIF3(en_phase_com,IF,IRM,2); %-8:+8
en_phase_com = LPA_expand(en_phase_com,sp_mag,win,hop,num_neighbor, 1);
% -----------------------------------

% the remian are complete with noisy phase
en_phase_com = en_phase_com+nysp_phase_com.*(en_phase_com==0);
en_phase = phase_decom(en_phase_com,hop);

% resynthese
nysp_process_irm2 = nysp_mag.*IRM.*exp(1j*en_phase);% 
ny_resy_irm2 = stft_resynthesis(nysp_process_irm2,win,noverlap,nfft );

ny_resy=ny_resy_irm2;

end

