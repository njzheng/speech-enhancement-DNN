function [ en_phase_com2 ] = addIF3(en_phase_com,IF,IRM,nght)
%ADDIF Summary of this function goes here
%   Detailed explanation goes here
% can also be applied to en_phase
% using weighted average of the phase: IRM is the weight
% ------------2017/5/19----------------------------

% to save the results
[nf,nt] = size(en_phase_com);
en_phase_com2= zeros(size(en_phase_com));

% first, for each time, we deal with a neighbor of time
% nght = 8; % -8 ~ +8
w_win = hamming(nght*2+1);
% cumulate IF
cIF = cumsum(IF,2);

% the range for weighted average, discard the beginning and the end
for i=1+nght:nt-nght
    
    xs = max(i-nght,1);   %start
    xe = min(i+nght,nt); %end
    
    block_phase = en_phase_com(:,xs:xe);
    if(sum(sum(block_phase))==0)
        continue;
    end
    
    block_cIF = cIF(:,xs:xe);
    block_cdIF = block_cIF - block_cIF(:,nght+1); % cumulate distance of IF
    
    % add the cdIF on block phase
    block_mphase = unwrap(block_phase - block_cdIF,[],2); % still remine problem!!
    
    % the weight
    block_IRM = IRM(:,xs:xe)*diag(w_win);
    w = block_IRM.*(block_phase~=0);
    w = w./(max(sum(w,2),0.001));
    
    en_phase_com2(:,i) = diag(w*(block_mphase).');
    
%     for j=1:numh
%         block_phase = useIF_time(block_phase,block_IF);
%         en_phase_com(ys:ye,xs:xe)=block_phase;
%     end
    
end



end

