function [ny_resy ] = synthesis_with_IRM(noisy, mask, feat_para) 
%SYNTHESIS_WITH_PHASE Summary of this function goes here
%   Detailed explanation goes here
% this funciton is for synthesis with phase information
% the noisy the time axis vector
%-------------------2017/4/28------------------------------------

Fs = feat_para.fs;
Lw = feat_para.Lw;
nfft = 2^nextpow2(Lw);
overlap = feat_para.overlap;
SNR = feat_para.snr_set;

noverlap  = round(Lw*overlap); % number of overlap
hop=Lw-noverlap; % time shift
win = hamming(Lw);
MASK_index = feat_para.MASK_index;

% get the spectrogram of noisy speech
% noisy = [zeros(Lw*overlap,1);noisy];
nysp = spectrogram(noisy,win,noverlap,nfft,Fs);
nysp_mag=abs(nysp);
nysp_phase=angle(nysp);% angle with lie between ����.

%% make use of the IRM mask
% dived the mask into magnitude and phase
IRM = mask;

nysp_process_irm = nysp_mag.*IRM.*exp(1j*nysp_phase);% 
ny_resy_irm = stft_resynthesis(nysp_process_irm,win,noverlap,nfft );

ny_resy=ny_resy_irm;

end

