function [ phase ] = useLPA_freq( phase,Lw,nfft,com_phase,num_neighbor)
%USELPA_FREQ Summary of this function goes here
%   Detailed explanation goes here
% using Linear Phase assumption to recover along the frequency bins
%----------------2017/4/13----------------------

phase_shift = -1*pi*(Lw-1)/nfft;

[nh,nw] = size(phase);% the size of the block phase

row_sum = sum(abs(phase),2); %sum along time axis
row_index = find(row_sum); %find the frequence bin with phase

phase_decom = phase+com_phase;% de_com

for i=1:length(row_index)
    % The accessible range
    ri = row_index(i);
    rs = max(ri-num_neighbor+1,1);
    re = min(ri+num_neighbor,nh);
    % for the end
    if(i+1<=length(row_index))
        re = max(ri,min(re,row_index(i+1)-num_neighbor));
    end
    % for the start
    if(i>1)
        rs = min(ri,max(rs, row_index(i-1)+num_neighbor));
    end
    
    for r = rs:re
        phase_decom(r,:) = phase_decom(ri,:) + (r-ri)*phase_shift;         
    end
    
end

phase = phase_decom-com_phase;% de_com

end

