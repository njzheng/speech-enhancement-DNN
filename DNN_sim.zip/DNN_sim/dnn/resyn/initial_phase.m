function [ en_phase ] = initial_phase( IRM,nysp_phase, alpha)
%INITIAL_PHASE Summary of this function goes here
%   Detailed explanation goes here
% select the intial phase as the basis

en_phase = (IRM>alpha).*nysp_phase;


end

