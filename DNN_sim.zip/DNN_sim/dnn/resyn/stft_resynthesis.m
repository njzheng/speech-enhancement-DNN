function [ speech ] = stft_resynthesis( STFT,win,noverlap,nfft )
%RESYNTHESIS Summary of this function goes here
%   Detailed explanation goes here
% STFT is the complexed valued matrix, whose column is the frequency bin.
% using OLA algorithm to reconstrunct the speech

wlen = length(win);
hop = wlen - noverlap;
% signal length estimation and preallocation
coln = size(STFT, 2);
xlen = wlen + (coln-1)*hop;
x = zeros(1, xlen);

% form a periodic hamming window
win = hamming(wlen, 'periodic');

% initialize the signal time segment index
indx = 0;

% perform ISTFT (via IFFT and Weighted-OLA)
if rem(nfft, 2)                     % odd nfft excludes Nyquist point
    for col = 1:coln
        % extract FFT points
        X = STFT(:, col);
        X = [X; conj(X(end:-1:2))];
        
        % IFFT
        xprim = real(ifft(X));
        xprim = xprim(1:wlen);
        
        % weighted-OLA
        x((indx+1):(indx+wlen)) = x((indx+1):(indx+wlen)) + (xprim.*win)';
        
        % update the index
        indx = indx + hop;
    end
else                                % even nfft includes Nyquist point
    for col = 1:coln
        % extract FFT points
        X = STFT(:, col);
        X = [X; conj(X(end-1:-1:2))];
        
        % IFFT
        xprim = real(ifft(X));
        xprim = xprim(1:wlen);
        
        % weighted-OLA
        x((indx+1):(indx+wlen)) = x((indx+1):(indx+wlen)) + (xprim.*win)';
        
        % update the index
        indx = indx + hop;
    end
end

% scale the signal
W0 = sum(win.^2);                  
x = x.*hop/W0;  
speech=x.';

% % generate time vector
% fs=16000;
% t = (0:xlen-1)/fs;                 
% t=t.';
end
