function [ phase ] = useIF_time(phase,IF)
%USEIF Summary of this function goes here
%   Detailed explanation goes here
%--------------------2017/4/13--------------------

[nh,nw] = size(phase);% the size of the block phase
assert(nh==size(IF,1));
assert(nw==size(IF,2)+1);

% the temp block phase assume the first is zero
IF_phase =  [zeros(nh,1),cumsum(IF,2)];

for i=1:nh
    if(norm(phase(i,:),1)==0)
        continue;% for the row without initialization
    end

    % for the intialized row (time vector)
    s_index = find(phase(i,:)); % the indexes of the initialized points
   
    if(length(s_index)==nw)
        continue; % all of the points have been intialized
    end
    
    for j=1:length(s_index)
        if(j==1)
            phase_diff = phase(i,s_index(j)) - IF_phase(i,s_index(j));
            phase(i,1:s_index(j)) = IF_phase(i,1:s_index(j))+ phase_diff;
        else
            phase_diff = phase(i,s_index(j)) - IF_phase(i,s_index(j));
            phase(i,s_index(j-1)+1:s_index(j)) = IF_phase(i,s_index(j-1)+1:s_index(j))+ phase_diff;
        end 
    end
    % from the index end to end
    if(s_index(end)~=nw)
        phase_diff = phase(i,s_index(end)) - IF_phase(i,s_index(end));
        phase(i,s_index(end)+1:nw) = IF_phase(i,s_index(end)+1:nw)+ phase_diff;  
    end

end

end

