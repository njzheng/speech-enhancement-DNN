function [ en_phase_com ] = LPA_expand(en_phase_com,sp_mag,win,hop,num_neighbor, isper)
%LPA_expand Summary of this function goes here
%   Detailed explanation goes here
%   num_neighbor = 1; % the neighbor can be used
%   consider the phase of the windown, focus on the pi flappings
% 1. get the pitch and its harmonic frequency bins
% 2. based on these bins to expand their neighbor bins
% ------------2017/4/28----------------------------

if(nargin<5)
    num_neighbor =1;
    isper = 1;
end

if(nargin<6)
    isper = 1;
end

% parameters
[nf,nt]=size(en_phase_com);
Lw= length(win);
nfft = (nf-1)*2;

% the compensate freqence
com_phase=wrapToPi(pi*((1:nf)-1).'/(nf-1)*hop*(1:nt));
en_phase_decom = en_phase_com+com_phase;% de_com

phase_s = -pi*(Lw-1)/nfft;

% 1. for each time bin, we averger the neighbor neghbor mag to 
% get the harmoic frequency indices ${\mal K}$
Hfreq = zeros(size(sp_mag)); % is -> 1
for i = 1: nt
    % get an average mean of the -1~+1, then get the peak
    tbin = mean(sp_mag(:,max(1,i-1):min(nt,i+1)),2);

    % search for the peak points, d is the increasement threshold
    d = 0.01;
    for j =2:nf-1
        % there exist initial value than it is a SNR peak
        if((en_phase_com(j,i)~=0)&&(tbin(j)>tbin(j-1)+d)&&(tbin(j)>tbin(j+1)+d))
            Hfreq(j,i) = 1;
        end
    end
end

% 2. for each harmoic points, we expend its freq neighbors
for i = 1: nt
    Hbar = Hfreq(:,i);
    hindex = find(Hbar); % find the non-zero indeces
    for f = 1:length(hindex)
        % lower neighbors start
        if f==1
            lneigborstart = max(1,hindex(f)-num_neighbor);
        else
            lneigborstart = max(hindex(f-1)+1,hindex(f)-num_neighbor);
        end
        
        % higher neighbors end
        if f== length(hindex)
            hneigborend = min(hindex(f)+num_neighbor,nf);
        else
            hneigborend = min(hindex(f)+num_neighbor,hindex(f+1)-1);
        end
        
        % add the linear phase
        hamfreq_phase = en_phase_decom(hindex(f),i);
        range = [lneigborstart:hneigborend];
        en_phase_decom(range,i) = hamfreq_phase+(range-hindex(f))*phase_s;
        
    end
end


% the additional processdure with wider range
if isper==1
    pitch = 5; % assume the distance of two harmonoics are no larger than that
    win = hamming(Lw);
    pwin = [win;zeros(nfft-Lw,1)];
    pwin = circshift(pwin,-Lw/2);
    Fwin = fft(pwin).*exp(-1j*pi*[1:nfft]'/nfft);
    Fwin_mag = abs(Fwin);

    S = zeros(nfft/2+1,1);
    for i = 1: nt
        Hbar = Hfreq(:,i);
        hindex = find(Hbar);
        for f = 1:length(hindex)              
            if (f < length(hindex)&&(hindex(f+1)-hindex(f)<=pitch))
                % recover all the band between the harmonic freqs
                A1 = sp_mag(hindex(f),i)/Fwin_mag(1);
                A2 = sp_mag(hindex(f+1),i)/Fwin_mag(1);
                for k = hindex(f):hindex(f+1)
                    S(k) = A1*Fwin_mag(k-hindex(f)+1)*exp(1j*(en_phase_decom(hindex(f),i)+(k-hindex(f))*phase_s))...
                        +A2*Fwin_mag(hindex(f+1)-k+1)*exp(1j*(en_phase_decom(hindex(f+1),i)+(k-hindex(f+1))*phase_s));               
                end     
                S_phase = angle(S(hindex(f):hindex(f+1)));
                en_phase_decom(hindex(f):hindex(f+1),i) = S_phase;          
            end
        end
    end
end

en_phase_com = en_phase_decom-com_phase;% com preserve zeros

en_phase_com(128:end,:) = 0;% discard the high freqs

% imagesc(Hfreq)
% axis xy
end

