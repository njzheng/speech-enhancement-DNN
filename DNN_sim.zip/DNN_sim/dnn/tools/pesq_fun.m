function [pesq_perf]=pesq_fun(mix_s,clean_s,ideal_r,est_r, fs,WAV_path) 
% this function write the wave and use the pesq tool to get the scores
%------2017/5/27--------------------------------------

global mainpath;

num_test_sents = length(mix_s);
est_pesq = zeros(num_test_sents,1);
ideal_pesq = zeros(num_test_sents,1);
unproc_pesq =zeros(num_test_sents,1);

% WAV_path = [dnn_path,filesep,'WAVE' filesep];
% if ~exist(WAV_path,'dir'); mkdir(WAV_path); end;


%   SCORES is a two element array: [ PESQ_MOS, MOS_LQO (ignore) ] 
%   for narrowband mode, or a scalar for the wideband mode: MOS_LQO
mode = 'nb';%  'nb' or wideband: 'wb'
binary = [mainpath,filesep,'dnn',filesep,'tools',filesep,'pesq.exe'];

%% write to wav files and run the exe
disp('writing waves ......');
fprintf('The pesq.exe can be only used under Windows system!\n');
warning('off','all');
parfor i=1:num_test_sents
   sig = mix_s{i};
   sig = sig/max(abs(sig))*0.9999;
   mixture_path=[WAV_path num2str(i) '_mixture.wav'];
   audiowrite(mixture_path, sig,fs);

   sig = clean_s{i};
   sig = sig/max(abs(sig))*0.9999;
   clean_path=[WAV_path num2str(i) '_clean.wav'];
   audiowrite(clean_path, sig,fs);

   sig = ideal_r{i};
   sig = sig/max(abs(sig))*0.9999;
   idea_path=[WAV_path num2str(i) '_ideal.wav'];
   audiowrite(idea_path,sig,fs);

   sig = est_r{i};
   sig = sig/max(abs(sig))*0.9999;
   estimate_path=[WAV_path num2str(i) '_estimated.wav'];
   audiowrite(estimate_path,sig,fs);


    %2. get the pesq scores, related with the clean speech
%         pesq2_mtlb( reference, degraded, fs, mode, binary)
    est_pesq(i) = pesq2_mtlb(clean_path, estimate_path, fs,mode, binary);
    ideal_pesq(i) = pesq2_mtlb(clean_path, idea_path, fs,mode, binary); 
    unproc_pesq(i) = pesq2_mtlb(clean_path, mixture_path, fs,mode, binary);
    fprintf(1,['#PESQ_single# '  ' index=%d unprocessed_pesq=%0.4f ideal_pesq=%0.4f est_pesq=%0.4f \n'],...
    i, unproc_pesq(i), ideal_pesq(i), est_pesq(i)); 
end

% sum the pesq all        
pesq_est_sum = sum(est_pesq);
pesq_ideal_sum = sum(ideal_pesq);
pesq_unproc_sum = sum(unproc_pesq);     

fprintf(1,['\n#PESQ_average# '  ' unprocessed_pesq=%0.4f ideal_pesq=%0.4f est_pesq=%0.4f \n'],...
pesq_unproc_sum/num_test_sents, pesq_ideal_sum/num_test_sents, pesq_est_sum/num_test_sents);

pesq_perf.est_pesq = est_pesq;
pesq_perf.ideal_pesq = ideal_pesq;
pesq_perf.unproc_pesq = unproc_pesq;

disp('finish waves');

end