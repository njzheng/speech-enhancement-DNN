function [ data ] = ARMA( data, mov_order)
%ARMA Summary of this function goes here
%   Detailed explanation goes here
% auto regressive moving average filter

[nt, nf] = size(data);

for i = 1:nt
    st = max(1,i-mov_order);
    ed = min(nt,i+mov_order);
    
    data(i,:) = mean(data(st:ed,:),1);  
end

end

