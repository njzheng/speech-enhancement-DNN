function snr = snr_fw_seg(signal, noise, fs, T, method, thresholdTrue,broadbandFalse)
%SNR_FW_SEG(SIGNAL, NOISE, FS, T, Method, ThresholdTrue,BroadBandFalse) computes
%the frequency weighted segmental signal-to-noise ratio.
%
%   SNR is computed on the signal and noise vectors using frame duration
%   of T [ms]. If input is a matrix, the SNR is computed along the columns.
%
%   T defaults to 20ms (T = 20)
%
%   Default Fs is 16kHz.
%
%   0dB lower and 35dB upper thresholding can be applied setting
%   thresholdTrue (default true = 1)
%
%   Method is 'A' as of now. 1/3 octave band weighting
%
%   If broadbandFalse is set to 0 the the weighted broadband is
%   computed. Default is 1 doing is frame-based.
%
%   Note: Last non-multiple of signal length is not included in the SNR
%   computations
   
   
% Author: Jacob Kj�rgaard, 2006
%
% Modified: 2006-10-09
% $Rev:$ $Date: 2006-10-09 15:46:34 +0200 (Mon, 09 Oct 2006) $

 
   if nargin < 7
      broadbandFalse=1;
      if nargin < 6,
	 thresholdTrue = 1;
	 if nargin < 5
	    method = 'A'; 
	 end
	 if nargin < 4,
	    T = []; % 20ms std frame length
      end
      if nargin < 3,
         fs = []; % 8khz
      end
      end
   end
   if (isempty(thresholdTrue))
      thresholdTrue=1;
   end

   if  (isempty(method))
      method='A';
   end
   
   if  (isempty(fs))
      fs=16000;
   end
   
   if (isempty(T))
      T = 20; % 20ms std frame length
   end
   
   %no of points in the fft
   N=14;

   [r, c] = size(signal);
   if (1 == r), % if input is row-wise, turn to column
      signal = signal';
      noise = noise';
      [r, c] = size(signal); % update size parameters
   end

   switch lower(method)
    case 'a'
     warning off MATLAB:nearlySingularMatrix
     [B,A]=adsgn(fs);
     warning on MATLAB:nearlySingularMatrix

     %% INLINE SNR_WEIGHTED_SII2 at the bottom
    case 'sii2' 
     % is done in a crappy way inline with if elses -
     % bad coding style
    otherwise
     disp 'Wrong type of argument "Method"'
     help snr_fw_seg
     return; %break if wrong input
   end
   
   if (broadbandFalse) 
      %do to frames
      [sig, blocks]=frame(signal, T, fs);
      [n]=frame(noise, T, fs);
      
      snr=zeros(c,blocks);
      for m=1:blocks % in time domain: weights are just a digital filter
	 if (lower(method) == 'sii2')
	    snr(:,m)=sii2(sig(:,m),n(:,m),fs,thresholdTrue);
	 else
	    sig_Z=filter(B,A,sig(:,m));
	    n_Z=filter(B,A,n(:,m));
	 
	    %dont compute frequency bands - operate on each freq-pin
	    if (thresholdTrue)
	       %tmp=sig_Z./(n_Z+1e-12); % add small security value
	       
	       %compute power!
	       tmp=diag(sig_Z'*sig_Z)./(diag(n_Z'*n_Z)+1e-12);
	       
	       %thresholding / clipping
	       K=find(3.12623e3<tmp); % if snr>35 then
	       tmp(K)=3.12623e3; % snr=35db else
	       K=find(tmp==0);  % if snr=-inf then /sig=0
	       tmp(K)=1; % snr=0
	    else
	       tmp=diag(sig_Z'*sig_Z)./diag(n_Z'*n_Z);
	    end
	    snr(:,m)=10*log10(tmp);
	 end
      end
   else
      %crappy code but it works
      if (lower(method) == 'sii2')
         snr=sii2(signal,noise,fs,thresholdTrue);
      else
	 sig_Z=filter(B,A,signal);
	 n_Z=filter(B,A,noise);
	 snr=10*log10(diag(sig_Z'*sig_Z)./diag(n_Z'*n_Z));
      end
   end
   
   
%% 100% rip-off from simon-doclo   
function snr2=sii2(signal,noise,fs,clipping)   
%Band importance function
   r=2^(1/6);
   if fs/2 > 4500;
      I=[83 95 150 289 440 578 653 711 818 844 882 898 868 844 771 527 364 185]*1e-4;
      F=[160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000];
      f2=F*r;
      n=sum(fs/2>f2);
      F=F(1:n);
      I=I(1:n);
   else
      I=[128 320 320 447 447 639 639 767 959 1182 1214 1086 1086 757]*1e-4;
      F=[200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000];
      f2=F*r;
      n=sum(fs/2>f2);
      F=F(1:n);
      I=I(1:n);
   end
   SNR=zeros(1,n);
   
   %calculation of the SNR values in the different bands
   for i=1:n
      [b,a] = oct3dsgn(F(i),fs,3);	

      Ep(i)=rmsdb(filter(b,a,signal));
      Np(i)=rmsdb(filter(b,a,noise));

      SNR(i)=Ep(i)-Np(i);

      if clipping 
	 SNR(i)=min(max(0,SNR(i)),35);
      end
   end
   snr2=I/sum(I)*SNR';  

%  100% rip-off from simon_doclo
function y=rmsdb(x)
   % Root Mean Square
%	if x is a vector, y = rms( x ) returns the root mean square
%	value of the elements of x.
%
%	if x is a matrix, y = rms( x ) returns the root mean square
%	value of each column of x.

[r,c] = size( x );
if c == 1,
   y = 10 * log10( x'*x / length(x) );
elseif r ==1,
   y = 10 * log10( x*x' / length(x) );
else
   y = 10 * log10( sum( x .* x ) / length(x) );
end
