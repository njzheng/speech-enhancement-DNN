function batchid = genBatchID(datasize,fixnum)
% (num_samples,opts.sgd_batch_size 1024);
% divide traindata into several batches, small fixnum is, the slice the
% batches is.

ndata = datasize;
nbatch = round(ndata/fixnum); 

batchid = zeros(2,nbatch);
for ii = 1:nbatch    
    first = (ii-1)*fixnum+1;
    last = ii*fixnum;
    
    batchid(1,ii) = first;
    if last <= ndata
        batchid(2,ii) = last;
    else
        batchid(2,ii) = ndata;
    end
    
end
