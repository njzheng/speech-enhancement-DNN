function ret = make_window_buffer(X, side_size)
% side_size is the neighbor size
% to make one column to contains several time axis frames
% pad the repeated column at 'pre' and 'post' along frame \times dimension

if side_size ~=0 
    [~, d] = size(X); % d is the feature size
    % make the first and end row repeated side_size, and transpose it
    X = [repmat(X(1,:), side_size,1); X; repmat(X(end,:), side_size, 1)].';
    winsize_in_frame = 2*side_size + 1;
    % reshape with overlap and transpose it recover
    ret = buffer(X(:), d*winsize_in_frame, d*winsize_in_frame-d, 'nodelay').';
else
    ret = X;
end

