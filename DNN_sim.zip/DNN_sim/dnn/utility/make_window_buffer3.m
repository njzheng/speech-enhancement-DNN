function ret = make_window_buffer3(X, idx, side_size, btime)
% (train_data_org,perm_idx,opts.train_neighbour);
% side_size is the neighbor size
% idx is the indeces that we want, is increasing sort
% to make one column to contains several time axis frames
% pad the repeated column at 'pre' and 'post' along frame \times dimension

if nargin<4
    btime =1;
end

[d, nt] = size(X); % d is the feature size
if side_size ~=0 
    % make the first and end row repeated side_size, and transpose it
    winsize_in_frame = 2*side_size + 1;
    
    ret_cell = cell(winsize_in_frame,1); % for each cell
    for i = 1: 2*side_size+1
        midx = min(nt, max(1,idx + i - (side_size+1)));
        ret_cell{i} = X(:,midx);
    end
    
    ret_mat = cell2mat(ret_cell);
    
    % reshape with overlap and transpose it recover
    if btime>1   
        % convert the cell to the matrix 
        ret = reshape(ret_mat,winsize_in_frame*d,[],btime); %3-D matrix
        ret = permute(ret,[2,1,3]);
    else
        ret = ret_mat.';
    end
    
else
    ret_mat = X(:,idx);
        % reshape with overlap and transpose it recover
    if btime>1   
        % convert the cell to the matrix 
        ret = reshape(ret_mat,d,[],btime); %3-D matrix
        ret = permute(ret,[2,1,3]);
    else
        ret = ret_mat.';
    end
end




