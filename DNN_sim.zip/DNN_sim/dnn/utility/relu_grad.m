function y = relu_grad(x)

y = double(x>0);