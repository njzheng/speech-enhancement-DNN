function [MVN_DATA_PATH] = mvn_store(noise_type, feat_type, snr_set, TMP_STORE,MASK_index,mov_order)
% mean variance normalization for test and train data not for label
% using AMRA : auto-regressieve moving average filter

format compact;
fprintf(1,'MVNing Feat=%s Noise=%s\n', feat_type, noise_type);

%% load the speech and features of test ; features of train
% E:\myMatlab\SENN\DNN_toolbox\DATA\factory\tmpdir\db-2
root_path = [TMP_STORE filesep 'db' num2str(snr_set)] %#ok<NOPRT>

% test_speeches: speeh_cell noise_cell mix_cell c_mat
speech_data_path = [root_path filesep 'mix' filesep 'test_' noise_type '_mix.mat'];
load(speech_data_path);

% test_features: 'feat_data','feat_label','START', 'END','feat_para','part','DFI'
test_feat_path=[root_path filesep 'feat' filesep 'test_' noise_type '_' feat_type,'_',num2str(MASK_index),'.mat'];
disp(['----loading: ' test_feat_path]);
load(test_feat_path); %test set
test_data = feat_data; 
test_label = feat_label; %#ok<NASGU>
clear feat_data feat_label

% train_set:
% train_feature: 'feat_data','feat_label','START', 'END', 'SIZE','feat_para','part'
train_feat_path = [root_path filesep 'feat' filesep 'train_' noise_type '_' feat_type,'_',num2str(MASK_index),'.mat'] %#ok<NOPRT>
disp(['----loading: ' train_feat_path]);
load(train_feat_path);
train_data = feat_data;
train_label = feat_label; % train_target
clear feat_data feat_label;

% the total number of frame of train_feat_data
total_frame=size(train_data, 1); 
cv_frame = floor(0.1 * total_frame); % used for validation with the first 10% 
fprintf(1,'----Percentage for check verification (cv) is %5.2f \n',0.1);
fprintf(1,'----Total=%d, cv=%d  train=%d\n',total_frame, cv_frame, total_frame - cv_frame);
cv_data = train_data(1:cv_frame,:);
cv_label = train_label(1:cv_frame,:); %#ok<NASGU>
% remove the cv part
train_data(1:cv_frame,:) = [];
train_label(1:cv_frame,:) = []; %#ok<NASGU>

fprintf(1,'----size: cv=%d x %d; size: test=%d x %d\n',size(cv_data),size(test_data));

%% process of the featurs of train
% construnct the dnn path in DATA director
global mainpath;
dnn_path=[mainpath,filesep,'DATA',filesep,noise_type,filesep,'dnn'];

% mean/var norm features alonge time axis
[train_data,tr_mu,tr_std] = mean_var_norm(train_data); 
% apply the normalization parameters (tr_mu,tr_std) into cv and test
% normalization is  only for data, not for labels (targets)
cv_data = mean_var_norm_testing(cv_data, tr_mu,tr_std); 
test_data = mean_var_norm_testing(test_data, tr_mu,tr_std);

%% using ARMA to smooth the temporal trajectories of all feature
% mov_order = 2; % -2:0:2
fprintf('the mov_order is :  %d\n',mov_order);
if mov_order >0
    train_data = ARMA(train_data, mov_order);  %#ok<NASGU> %along the time axis
    cv_data = ARMA(cv_data, mov_order); %#ok<NASGU>
    test_data = ARMA(test_data, mov_order);  %#ok<NASGU>
end

%% save the normalized data into MVN_STORE
mvn_path = [dnn_path,filesep,'MVN_STORE', filesep];
if ~exist(mvn_path,'dir'); mkdir(mvn_path); end;
MVN_DATA_PATH = [mvn_path 'mvn_' noise_type '_' feat_type '_' num2str(snr_set),'_',num2str(MASK_index) '.mat'] %#ok<NOPRT>
save(MVN_DATA_PATH, 'train_data','train_label','cv_data','cv_label','test_data','test_label', 'DFI',...
 'mix_cell', 'noise_cell', 'speech_cell', 'c_mat','mov_order', '-v7.3');%also saved test mixes

% pauses for 1 second.
pause(1);

end
