function [test_perf]= checkPerformance(model,opts,noise_type, feat_type,MASK_index)
% this function is for checking the performance of the dnn model

%% load the mvn data
mix_db=opts.db;
global mainpath;
dnn_path=[mainpath,filesep,'DATA',filesep,noise_type,filesep,'dnn'];
mvn_path = [dnn_path,filesep,'MVN_STORE' filesep];
MVN_DATA_PATH = [mvn_path 'mvn_' noise_type '_' feat_type '_' num2str(mix_db),'_',num2str(MASK_index), '.mat'] %#ok<NOPRT>
mvn_handle = matfile(MVN_DATA_PATH,'Writable',false); % read only
test_data = mvn_handle.test_data;
test_label = mvn_handle.test_label;
test_data = make_window_buffer(test_data, opts.train_neighbour); % add the dimension of the number of columns

%% use this model to predic on test set rather than dev set.
if (strcmp(feat_type, 'Comp_feat'))
    switch MASK_index
        case 5 % STFT-IRM
            [test_perf, stoi_perf,estoi_perf,pesq_perf,SDR_perf]= checkPerformance_IRM(model,test_data,test_label,opts, 1,mvn_handle,noise_type, feat_type);
            disp('# STFT-IRM');
        case 6 % STFT-IAM : reconstruct as IRM
            [test_perf, stoi_perf,estoi_perf,pesq_perf,SDR_perf]= checkPerformance_IRM(model,test_data,test_label,opts, 1,mvn_handle,noise_type, feat_type);
            disp('# STFT-IAM');
        case 7 % STFT-IAM+IFD : 
            [test_perf, stoi_perf,estoi_perf,pesq_perf,SDR_perf]= checkPerformance_pIAM(model,test_data,test_label,opts, 1,mvn_handle,noise_type, feat_type);
            disp('#  IAM+IFD :');
        otherwise
            disp('# No this label choice');
            assert(0);
    end   
end
fprintf('\ntest_set: Best model (selected by validation set) with perf %2.4f\n',test_perf);

% compute the average performance
avg_estoi = mean([estoi_perf.unproc_estoi,estoi_perf.ideal_estoi,estoi_perf.est_estoi]); %#ok<NASGU>
avg_stoi = mean([stoi_perf.unproc_stoi, stoi_perf.ideal_stoi,stoi_perf.est_stoi]); %#ok<NASGU>
avg_pesq = mean([pesq_perf.unproc_pesq, pesq_perf.ideal_pesq,pesq_perf.est_pesq]);%#ok<NASGU>
avg_SDR = mean([SDR_perf.unproc_SDR, SDR_perf.ideal_SDR, SDR_perf.est_SDR]);%#ok<NASGU>

%% save model
model_path=[dnn_path,filesep,'MODEL' filesep];
if ~exist(model_path,'dir'); mkdir(model_path); end

global feat_para; %#ok<NUSED>
model_name = [model_path,'model',noise_type,'_', num2str(mix_db),'_',num2str(MASK_index),'.mat'];
save(model_name,'test_perf','SDR_perf','estoi_perf','avg_estoi','avg_stoi','avg_pesq','avg_SDR','feat_para', '-append');%also saved test mixes
end