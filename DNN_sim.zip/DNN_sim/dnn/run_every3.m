function [model,opts]=run_every3(MVN_DATA_PATH, noise_type, feat_type, mix_db, MASK_index,model,opts)
% This function is the entrance of dnn trainning
% the orginal name is run_every which is conflict with the file in
% get_feat director
% using multi-frame targets and inputs

%% GPU detection
try
   gpuDevice;
catch %err
   disp('no gpu available, use cpu instead');
end

disp('Done with GPU detection.');
format compact

fprintf(1,'Feat=%s Noise=%s MASK_index=%d\n', feat_type, noise_type, MASK_index);
tic;
%% load the mvn data
% allocate the data and label
mvn_handle = matfile(MVN_DATA_PATH,'Writable',false); % read only

%% --network intialization--
% if is fune tuning, using the existing model
isfunetuning = 0;
if(nargin ==7)
    disp('fune tuning with the existing model!');
    isfunetuning = 1;
end

% set the parameter of dnn, called opts, construct a new model and opt
if(isfunetuning ==0)
    opts=dnn_para_set(mix_db);
    % set inputs and outputs structure
    [~, singleframe_input] = size(mvn_handle,'test_data'); % num_frame x (fs+feat) 
    % the output does not need to be averaged 
    [~, singleframe_output] = size(mvn_handle,'test_label');
    % the output need to be averaged overlapped
    dim_input=singleframe_input*(2*opts.train_neighbour+1);
    dim_output = singleframe_output*(2*opts.label_neighbour+1);
    opts.net_struct = [dim_input, opts.hid_struct, dim_output];
    disp(opts);
else
    assert(length(model)==length(opts.net_struct)-1);
    [~, singleframe_input] = size(mvn_handle,'test_data'); % num_frame x (fs+feat) 
    % the output does not need to be averaged 
    [~, singleframe_output] = size(mvn_handle,'test_label');
    % the input need to be averaged
    dim_input=singleframe_input*(2*opts.train_neighbour+1);
    dim_output = singleframe_output*(2*opts.label_neighbour+1);
    assert(isequal(opts.net_struct, [dim_input, opts.hid_struct, dim_output]));
    disp(opts);
end

%% main training function
if(isfunetuning ==0)
    [model, netgrad] = funcDeepNetTrain3(mvn_handle,opts,MASK_index); % use mvn to check the quality
else
    [model, netgrad] = funcDeepNetTrain3(mvn_handle,opts,MASK_index,model); % use mvn to check the quality
end
% model.netg = netgrad;

train_time = toc;
fprintf('\nTraining done. Elapsed time: %2.2f sec\n',train_time);

% save the model and opt
global mainpath;
dnn_path=[mainpath,filesep,'DATA',filesep,noise_type,filesep,'dnn'];
model_path=[dnn_path,filesep,'MODEL' filesep];
if ~exist(model_path,'dir'); mkdir(model_path); end
model_name = [model_path,'model',noise_type,'_', num2str(mix_db),'_',num2str(MASK_index),'.mat'];
save(model_name, 'model','opts', '-v7.3');%also saved test mixes


end
